<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Validation</title>
</head>
<body>
    <h1>Email Validation</h1>
    <form action="validate_email.php" method="get">
        <label for="email">Enter Email:</label>
        <input type="text" id="email" name="email" required>
        <button type="submit">Validate</button>
    </form>

    <?php
    if (isset($_GET['email'])) {
        $email = urlencode($_GET['email']);
        $url = "http://154.41.233.1:5001/validate_email?email=$email";

        // Initialize cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Decode and display response
        $response_data = json_decode($response, true);
        
        if ($http_code == 200) {
            echo "<p>Email is <strong>valid</strong>.</p>";
        } else {
            echo "<p>Email is <strong>invalid</strong>.</p>";
        }
    }
    ?>
</body>
</html>
