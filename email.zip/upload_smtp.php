<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['smtpFile'])) {
    $file = $_FILES['smtpFile']['tmp_name'];
    $handle = fopen($file, 'r');
    $conn = getDatabaseConnection();
    while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
        $host = $data[0];
        $username = $data[1];
        $password = $data[2];
        $encryption = $data[3];
        $port = $data[4];
        $imap_host = $data[5];
        $imap_port = $data[6];
        $name = $data[7];
        $sql = "INSERT INTO smtp_settings (host, username, password, encryption, port, imap_host, imap_port, name) 
                VALUES ('$host', '$username', '$password', '$encryption', '$port', '$imap_host', '$imap_port', '$name')";
        $conn->query($sql);
    }
    fclose($handle);
    $conn->close();
    echo "SMTP settings uploaded successfully.";
}
?>
