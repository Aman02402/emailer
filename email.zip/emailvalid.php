<?php

function isEmailValid($email) {
    // Extract domain from email address
    list(, $domain) = explode('@', $email);

    // Check MX records
    if (!checkMX($domain)) {
        return false;
    }

    // Perform SMTP check
    if (!checkSMTP($email, $domain)) {
        return false;
    }

    return true;
}

function checkMX($domain) {
    // Get MX records for the domain
    $mxRecords = dns_get_record($domain, DNS_MX);
    return !empty($mxRecords);
}

function checkSMTP($email, $domain) {
    $mxServer = getMXServer($domain);
    if (!$mxServer) {
        return false;
    }

    $socket = @fsockopen($mxServer, 25, $errno, $errstr, 10);
    if (!$socket) {
        return false;
    }

    // Read server response
    fgets($socket);

    // Send EHLO command
    fwrite($socket, "EHLO test.com\r\n");
    fgets($socket);

    // Send MAIL FROM command
    fwrite($socket, "MAIL FROM:<test@example.com>\r\n");
    fgets($socket);

    // Send RCPT TO command
    fwrite($socket, "RCPT TO:<$email>\r\n");
    $response = fgets($socket);

    fclose($socket);

    // Check response code for RCPT TO
    return strpos($response, '250') !== false;
}

function getMXServer($domain) {
    $mxRecords = dns_get_record($domain, DNS_MX);
    if ($mxRecords) {
        // Sort by preference
        usort($mxRecords, function($a, $b) {
            return $a['pri'] - $b['pri'];
        });
        return $mxRecords[0]['target'];
    }
    return false;
}

// Test email
$emailToCheck = 'aman051200000@gmail.com';

if (isEmailValid($emailToCheck)) {
    echo 'Email is valid.';
} else {
    echo 'Email is invalid.';
}
?>
