<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    $conn = getDatabaseConnection();
    $sql = "INSERT INTO content (subject, body) VALUES ('$subject', '$body')";
    if ($conn->query($sql) === TRUE) {
        echo "Content added successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
    $conn->close();
}
?>
