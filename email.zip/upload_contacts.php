<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Contacts</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center">Upload Contacts</h2>
        <form id="upload-form" enctype="multipart/form-data">
            <div class="form-group">
                <label for="fileInput">Select Excel File</label>
                <input type="file" class="form-control-file" id="fileInput" accept=".xlsx, .xls">
            </div>
            <button type="button" class="btn btn-primary" onclick="uploadFile()">Upload</button>
        </form>

        <div id="segmentNameSection" class="mt-5 d-none">
            <h4>Provide Segment Name for Uploaded Contacts</h4>
            <div class="form-group">
                <label for="segmentName">Segment Name</label>
                <input type="text" class="form-control" id="segmentName">
            </div>
            <button type="button" class="btn btn-success" onclick="saveSegment()">Save Segment</button>
        </div>

        <div id="contactsListSection" class="mt-5 d-none">
            <h4>Contact List</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Emailed</th>
                        <th>Segment</th>
                        <th>Active</th>
                    </tr>
                </thead>
                <tbody id="contactsTableBody">
                    <!-- Contacts will be appended here -->
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function uploadFile() {
            const fileInput = document.getElementById('fileInput');
            if (fileInput.files.length === 0) {
                alert('Please select a file to upload');
                return;
            }

            const formData = new FormData();
            formData.append('file', fileInput.files[0]);

            fetch('/upload-contacts', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('segmentNameSection').classList.remove('d-none');
                    document.getElementById('contactsListSection').classList.remove('d-none');
                    populateContactsTable(data.contacts);
                } else {
                    alert('Failed to upload file');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        function saveSegment() {
            const segmentName = document.getElementById('segmentName').value;
            if (segmentName === '') {
                alert('Please provide a segment name');
                return;
            }

            // Implement the logic to save the segment name for the uploaded contacts
            alert(`Segment name "${segmentName}" saved successfully!`);
        }

        function populateContactsTable(contacts) {
            const contactsTableBody = document.getElementById('contactsTableBody');
            contactsTableBody.innerHTML = '';

            contacts.forEach(contact => {
                const row = document.createElement('tr');

                const idCell = document.createElement('td');
                idCell.textContent = contact.id;
                row.appendChild(idCell);

                const emailCell = document.createElement('td');
                emailCell.textContent = contact.email;
                row.appendChild(emailCell);

                const nameCell = document.createElement('td');
                nameCell.textContent = contact.name;
                row.appendChild(nameCell);

                const emailedCell = document.createElement('td');
                emailedCell.textContent = contact.emailed;
                row.appendChild(emailedCell);

                const segmentCell = document.createElement('td');
                segmentCell.textContent = contact.segment;
                row.appendChild(segmentCell);

                const activeCell = document.createElement('td');
                activeCell.textContent = contact.active;
                row.appendChild(activeCell);

                contactsTableBody.appendChild(row);
            });
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
