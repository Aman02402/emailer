<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe from Mailing List</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0ecec;
        }
        .unsubscribe-container {
            background-color: #ffffff;
            padding: 40px;
            max-width: 600px;
            margin: 100px auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #FF5C00;
            font-size: 24px;
            font-weight: bold;
        }
        .email-header {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .note {
            font-size: 14px;
            margin-bottom: 20px;
        }
        .form-group select {
            max-width: 300px;
            margin: 0 auto;
        }
        .btn-unsubscribe {
            background-color: #2196f3;
            color: white;
            padding: 10px 30px;
            border-radius: 5px;
            border: none;
            font-size: 16px;
        }
    </style>
</head>
<body>

    <div class="unsubscribe-container">
        <p class="email-header">
            <?php echo htmlspecialchars($_GET['email']); ?> <br> is subscribed to our mailing list(s).
        </p>
        <h1>Unsubscribe from our mailing list</h1>
        <p class="note">You will be unsubscribed only for the campaign associated with this email.</p>
        <p class="note">To help us improve, please let us know the reason why:</p>

        <form action="unsubscribez.php" method="GET">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>">
            <input type="hidden" name="campaign_id" value="<?php echo htmlspecialchars($_GET['campaign_id']); ?>">

            <div class="form-group">
                <select class="form-control" id="selectUnsubscribeReason" name="unsubscribereason" required>
                    <option value="">Please select reason</option>
                    <option value="Your emails are not relevant to me">Your emails are not relevant to me</option>
                    <option value="Your emails are too frequent">Your emails are too frequent</option>
                    <option value="I don't remember signing up for this">I don't remember signing up for this</option>
                    <option value="I no longer want to receive these emails">I no longer want to receive these emails</option>
                    <option value="The emails are spam and should be reported">The emails are spam and should be reported</option>
                    <option value="Others">Others</option>
                </select>
            </div>
            <button type="submit" class="btn btn-unsubscribe">Unsubscribe</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
