 <?php
$servername = "localhost";
$username = "u291199864_email";
$password = "Email123@123";
$dbname = "u291199864_email";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>