<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Database connection
function getDatabaseConnection() {
    $servername = "localhost";
    $username = "u291199864_email";
    $password = "Email123@123";
    $dbname = "u291199864_email";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Initialize counters and settings
function initializeCounters($conn) {
    // Create the content_counter table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS content_counter (
        counter INT(11) NOT NULL DEFAULT 0
    )");

    // Create the smtp_counter table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS smtp_counter (
        counter INT(11) NOT NULL DEFAULT 0
    )");

    // Insert initial value for content_counter if it doesn't exist
    $conn->query("INSERT INTO content_counter (counter)
    SELECT 0
    WHERE NOT EXISTS (SELECT * FROM content_counter)");

    // Insert initial value for smtp_counter if it doesn't exist
    $conn->query("INSERT INTO smtp_counter (counter) 
    SELECT 0 
    WHERE NOT EXISTS (SELECT * FROM smtp_counter)");
}

// Get current counter value from the specified table
function getCurrentCounter($conn, $table) {
    $result = $conn->query("SELECT counter FROM $table LIMIT 1");
    $row = $result->fetch_assoc();
    return (int)$row['counter'];
}

// Update counter value in the specified table
function updateCounter($conn, $table, $newCounter) {
    $conn->query("UPDATE $table SET counter = $newCounter");
}

// Fetch SMTP settings from the database
function getSmtpSettings($conn) {
    $result = $conn->query("SELECT * FROM smtp_settings WHERE active=1 ORDER BY id");
    $settings = [];

    while ($row = $result->fetch_assoc()) {
        $settings[] = $row;
    }

    return $settings;
}

// Fetch email content from the database
function getEmailContent($conn, $contentCounter) {
    // Get email content based on the current counter value
    $result = $conn->query("SELECT * FROM content where active_inactive=1 ORDER BY id LIMIT 1 OFFSET $contentCounter");
    $row = $result->fetch_assoc();

    // Reset counter if no content is found and fetch the first content
    if (!$row) {
        $contentCounter = 0;
        $conn->query("UPDATE content_counter SET counter = $contentCounter");
        $result = $conn->query("SELECT * FROM content ORDER BY id LIMIT 1 OFFSET $contentCounter");
        $row = $result->fetch_assoc();
    }

    return $row;
}

// Fetch a contact from the database
function getContact($conn) {
    $result = $conn->query("SELECT * FROM contacts WHERE emailed = 0 LIMIT 1");
    return $result->fetch_assoc();
}

// Send email using PHPMailer
function sendEmail($mail, $currentSetting, $contactRow, $subject, $body,$token) {
    try {
        // Setup PHPMailer with SMTP settings
        $mail->isSMTP();
        $mail->Host       = $currentSetting['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $currentSetting['username'];
        $mail->Password   = $currentSetting['password'];
        $mail->SMTPSecure = $currentSetting['encryption'];
        $mail->Port       = $currentSetting['port'];

 

        $username = $currentSetting['username'];
        $name = $currentSetting['name'];
        
        // Set sender and recipient
        $mail->setFrom($username, $name);

        $mail->addAddress($contactRow['email'], $contactRow['name']);
        
        // Replace placeholders in the email body
        $body = str_replace('{{name}}', $contactRow['name'], $body);
        $subject = str_replace('{{name}}', $contactRow['name'], $subject);
        $body = str_replace('{{Sendername}}', $name, $body);
       $uurl="https://welive24.com/email/unsubscribe.php?token=". $token ;
        // $mail->addCustomHeader('List-Unsubscribe', $uurl);

         
        $unsubscribe_url = '<a href="'.$uurl.'" >Unsubscribe</a>';
 
        $body = str_replace('{{unsubscribes}}', $unsubscribe_url, $body);

 
        // Add tracking image to the email body
        $body .= "<img src='https://welive24.com/email/track_email.php?id=$token' alt='' width='1' height='1' />";

        // Setup email format and subject
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);
        $mail->addCustomHeader('X-Priority', '1'); // High priority
        $mail->addCustomHeader('X-MSMail-Priority', 'High'); // For Outlook
        $mail->addCustomHeader('Importance', 'High'); // For some clients


        // Enable debug output (0 for none, 3 for detailed output)
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';

        // Send email
        $mail->send();
        echo "Message sent using {$currentSetting['username']} to {$contactRow['email']}\n";

        return $token;
    } catch (Exception $e) {
        // Handle errors in sending
        echo "Message could not be sent using {$currentSetting['username']}. Mailer Error: {$mail->ErrorInfo}\n";
        return false;
    }
}

// Log email details in the database
function logEmail($conn, $token, $contactEmail, $imapUser, $subject, $compaign_id, $contact_id, $smtp_id, $list_id, $status = '0') {
  
  
    $sql = "INSERT INTO email_logs (token, recipient_email, from_email, subject, sent_date, viewed, compaign_id, contact_id, smtp_id, list_id, status) 
            VALUES ('$token', '$contactEmail', '$imapUser', '$subject', NOW(), '0', '$compaign_id', '$contact_id', '$smtp_id', '$list_id', '$status')";

    // Insert or update the log record
    if ($conn->query($sql) === TRUE) {
        echo "Record inserted in Email Logs successfully\n";
    } else {
        echo "Error inserting/updating record: " . $conn->error . "\n";
    }
}

// Mark contact as emailed in the database
function markContactEmailed($conn, $contactRow) {
    $id = (int)$contactRow['id'];
    $sql = "UPDATE contacts SET emailed = '1' WHERE id = $id";

    // Update the contact record
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully\n";
    } else {
        echo "Error updating record: " . $conn->error . "\n";
    }
}

// Remove bounced contact from the database
function removeBouncedContact($conn, $contactRow) {
    $id = (int)$contactRow['id'];
    $sql = "DELETE FROM contacts WHERE id = $id";

    // Delete the contact record
    if ($conn->query($sql) === TRUE) {
        echo "Bounced contact removed successfully\n";
    } else {
        echo "Error removing contact: " . $conn->error . "\n";
    }
}

 
 function checkBounceStatus($email,$username) {
    $apiUrl = "https://welive24.com/email/bounce.php?username=" . urlencode($username)."&email=" . urlencode($email);
    $response = file_get_contents($apiUrl);
    
    if ($response === FALSE) {
        return 'API request failed';
    }

echo $response;
    $data = json_decode($response, true);
    print_r($data);

    if (isset($data['status'])) {
        return $data['status'];
    } elseif (isset($data['error'])) {
        return $data['error'];
    } else {
        return 'unknown';
    }
}
 
 
// Check if folder exists and create if not
function checkAndCreateFolder($imapStream, $imapServer, $imapPort, $sentFolder) {
    $folders = imap_list($imapStream, "{{$imapServer}:$imapPort/imap/ssl}", "*");
    if ($folders === false) {
        echo "Failed to list folders: " . imap_last_error() . "\n";
        return false;
    }

    if (!in_array("{{$imapServer}:$imapPort/imap/ssl}$sentFolder", $folders)) {
        if (!imap_createmailbox($imapStream, imap_utf7_encode("{{$imapServer}:$imapPort/imap/ssl}$sentFolder"))) {
            echo "Failed to create folder: " . imap_last_error() . "\n";
            return false;
        }
        echo "Folder $sentFolder created successfully\n";
    }
    return true;
}

 
 
 function saveToSentFolder($mail, $currentSetting, $message) {
    $imapServer = $currentSetting['imap_host'];
    $imapUser = $currentSetting['username'];
    $imapPass = $currentSetting['password'];
    $imapPort = $currentSetting['imap_port'];
    $sentFolder = 'INBOX.Sent';

    $imapStream = imap_open("{{$imapServer}:$imapPort/imap/ssl}", $imapUser, $imapPass);

    if ($imapStream === false) {
        echo "Failed to connect to IMAP server: " . imap_last_error() . "\n";
        return false;
    }

    if (!checkAndCreateFolder($imapStream, $imapServer, $imapPort, $sentFolder)) {
        imap_close($imapStream);
        return false;
    }

    $result = imap_append($imapStream, "{{$imapServer}:$imapPort/imap/ssl}$sentFolder", $message);

    if ($result === false) {
        echo "Failed to save email to Sent folder: " . imap_last_error() . "\n";
        return false;
    }

    imap_close($imapStream);
    echo "Email saved to Sent folder successfully\n";
    return true;
}
 

// Main email sending process
$conn = getDatabaseConnection();
initializeCounters($conn);

// Get current counter values
$smtpCounter = getCurrentCounter($conn, 'smtp_counter');
$contentCounter = getCurrentCounter($conn, 'content_counter');

// Fetch SMTP settings and initialize PHPMailer
$smtpSettings = getSmtpSettings($conn);
$mail = new PHPMailer(true);

// Fetch the next contact to email
$contactRow = getContact($conn);
if ($contactRow) {
    // Get the current SMTP setting and email content
    $currentSetting = $smtpSettings[$smtpCounter % count($smtpSettings)];
    $emailContent = getEmailContent($conn, $contentCounter);

    $subject = $emailContent['subject'];
    $body = $emailContent['body'];
            $token = md5(time() . $contactRow['email'] . $contactRow['name']);

    // // Send the email and receive a tracking token
    $token = sendEmail($mail, $currentSetting, $contactRow, $subject, $body,$token);
    sleep(10);
    
    
 
    // Add delay to avoid rate-limiting issues
 

 if ($token !== false) {
       

        // Check email status
        $imapServer = $currentSetting['imap_host'];
        $imapPort = $currentSetting['imap_port'];
        $imapUser = $currentSetting['username'];
        $imapPass = $currentSetting['password'];

        $imapStream = imap_open("{{$imapServer}:$imapPort/imap/ssl}", $imapUser, $imapPass);

        if ($imapStream === false) {
            echo "Failed to connect to IMAP server: " . imap_last_error() . "\n";
        } else {
            $status = checkBounceStatus($contactRow['email'],$imapUser);
            echo "Email status for {$contactRow['email']}: $status".'<br> from'.$imapUser;

            if ($status == 'delivered') {
                
                $message = $mail->getSentMIMEMessage();
                saveToSentFolder($mail, $currentSetting, $message);
                   markContactEmailed($conn, $contactRow);
                 logEmail($conn, $token, $contactRow['email'], $currentSetting['username'], $subject, $emailContent['compaign_id'], $contactRow['id'], $currentSetting['id'], $contactRow['list_id'], 0);

            } elseif ($status == 'spam' ) {
                                 logEmail($conn, $token, $contactRow['email'], $currentSetting['username'], $subject, $emailContent['compaign_id'], $contactRow['id'], $currentSetting['id'], $contactRow['list_id'], 3);

                
            }else{
                                 logEmail($conn, $token, $contactRow['email'], $currentSetting['username'], $subject, $emailContent['compaign_id'], $contactRow['id'], $currentSetting['id'], $contactRow['list_id'], 2);

                 removeBouncedContact($conn, $contactRow);

            }

            imap_close($imapStream);
        }
    }


 
        // Update counters
        $smtpCounter++;
        $contentCounter++;
        updateCounter($conn, 'smtp_counter', $smtpCounter);
        updateCounter($conn, 'content_counter', $contentCounter);
    
}

// Close the database connection
$conn->close();
?>
