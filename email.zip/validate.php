<?php

function validateEmail($email) {
    $email = trim($email);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "Invalid email format.";
    }

    // Extract domain from email
    list($user, $domain) = explode('@', $email);

    // Check if domain has MX records
    if (!checkdnsrr($domain, 'MX')) {
        return "Domain does not have MX records.";
    }

    // Get MX records
    getmxrr($domain, $mxHosts);

    // Define SMTP server configurations (reduced for optimization)
    $smtpServers = [
        'smtp.gmail.com' => [465, 587],
        'smtp.live.com' => [587],
        'smtp.office365.com' => [587],
        'smtp.mail.yahoo.com' => [465],
        'smtp.aol.com' => [587]
    ];

    // Try MX hosts first
    foreach ($mxHosts as $host) {
        foreach ([25, 587, 465] as $port) {
            if (smtpCheck($host, $port, $domain, $email)) {
                return "The email address is valid.";
            }
        }
    }

    // Try provider-specific hosts
    foreach ($smtpServers as $host => $ports) {
        foreach ($ports as $port) {
            if (smtpCheck($host, $port, $domain, $email)) {
                return "The email address is valid.";
            }
        }
    }

    return "The email address is invalid.";
}

function smtpCheck($host, $port, $domain, $email) {
    // Connect to SMTP server
    $connection = @fsockopen($host, $port, $errno, $errstr, 2); // Reduced timeout

    // Check if connection is established
    if (!$connection) {
        return false;
    }

    // Set socket timeout
    stream_set_timeout($connection, 2); // Reduced timeout

    // Say hello to the server
    $response = getSmtpResponse($connection, "HELO $domain\r\n");

    // Initiate mail from

    // Verify the recipient
    $response = getSmtpResponse($connection, "RCPT TO: <$email>\r\n");

    // Close the connection
    fwrite($connection, "QUIT\r\n");
    fclose($connection);

    // Check the response code
    if (strpos($response, '250') !== false || strpos($response, '450') !== false) {
        return true;
    }

    return false;
}

function getSmtpResponse($connection, $command) {
    fwrite($connection, $command);
    $response = '';
    while ($str = fgets($connection, 1024)) {
        $response .= $str;
        if (substr($str, 3, 1) == ' ' || feof($connection)) break;
    }
    return $response;
}

// Example usage
$email = "aman051erytfuguhjnk200000@gmail.com";
echo validateEmail($email);
?>
s