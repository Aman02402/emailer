import smtplib
import re
from email.utils import parseaddr

def is_valid_email(email):
    """
    Validate the email format and check if the email domain has an MX record
    """
    # Validate email format
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return False
    
    # Parse email address
    email_address = parseaddr(email)[1]
    
    # Extract domain
    domain = email_address.split('@')[1]
    
    try:
        # Get MX record for domain
        records = smtplib.SMTP('8.8.8.8')
        records.connect(domain, 25)
        records.helo(domain)
        records.quit()
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False

# Example usage
email = "test@example.com"
if is_valid_email(email):
    print(f"{email} is a valid email address.")
else:
    print(f"{email} is not a valid email address.")
