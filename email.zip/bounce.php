<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Database connection
function getDatabaseConnection() {
    $servername = "localhost";
    $username = "u291199864_email";
    $password = "Email123@123";
    $dbname = "u291199864_email";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
function checkEmailStatus($imapHost, $imapPort, $imapUser, $imapPass) {
    // Connect to the IMAP server
    $imapStream = imap_open("{{$imapHost}:$imapPort/imap/ssl}", $imapUser, $imapPass);

    if ($imapStream === false) {
        echo "Failed to connect to IMAP server: " . imap_last_error() . "\n";
        return 'IMAP connection failed';
    }

    // Search criteria for undelivered emails from "MAILER-DAEMON"
    $today = date('d-M-Y');
    $searchCriteria = 'FROM "MAILER-DAEMON" SINCE "' . $today . '"';
    $emails = imap_search($imapStream, $searchCriteria);

    if ($emails) {
        // Sort emails by number to get the latest undelivered email
        rsort($emails);
        $latestEmailNumber = $emails[0];

        // Fetch the email body
        $body = imap_fetchbody($imapStream, $latestEmailNumber, 1);
        $body .= imap_fetchbody($imapStream, $latestEmailNumber, 2); // Check additional parts if needed

        // Analyze the bounce status based on the email body content
        if (strpos($body, 'does not exist') !== false || strpos($body, '550-5.1.1') !== false) {
            imap_close($imapStream);
            return 'hard bounce';
        }

        if (strpos($body, 'connect to') !== false && strpos($body, 'Connection timed out') !== false) {
            if (strpos($body, 'Delivery failed') !== false || strpos($body, 'failed') !== false) {
                imap_close($imapStream);
                return 'hard bounce';
            }
        }

        if (strpos($body, 'Connection timed out') !== false || strpos($body, 'mailbox is temporarily unavailable') !== false) {
            if (strpos($body, 'retry') !== false) {
                imap_close($imapStream);
                return 'soft bounce';
            }
        }

        if (strpos($body, 'mailbox is disabled') !== false || strpos($body, '554 30 Sorry') !== false) {
            imap_close($imapStream);
            return 'disabled mailbox';
        }

        if (strpos($body, 'marked as spam') !== false || strpos($body, 'considered as spam') !== false) {
            imap_close($imapStream);
            return 'spam';
        }

        if (strpos($body, 'not delivered') !== false || strpos($body, 'could not be delivered') !== false) {
            imap_close($imapStream);
            return 'delivery failure';
        }

        // If none of the above, consider it delivered
        imap_close($imapStream);
        return 'delivered';
    } else {
        // No undelivered emails found
        imap_close($imapStream);
        return 'delivered';
    }
}


// API Endpoint to check bounce status
if (isset($_GET['email']) &isset($_GET['username']) ) {
    $email = $_GET['email'];
    $username = $_GET['username'];
 
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $conn = getDatabaseConnection();

        $smtpSettingsQuery = "SELECT * FROM smtp_settings WHERE username='$username' LIMIT 1";
        $result = $conn->query($smtpSettingsQuery);
        $smtpSettings = $result->fetch_assoc();

        if ($smtpSettings) {
            $status = checkEmailStatus(
                $smtpSettings['imap_host'],
                $smtpSettings['imap_port'],
                $smtpSettings['username'],
                $smtpSettings['password'],
                $email
            );

             echo json_encode(['status' => $status]);
        } else {
            echo json_encode(['error' => 'No active SMTP settings found.']);
        }

        $conn->close();
    } else {
        echo json_encode(['error' => 'Invalid email address.']);
    }
} else {
    echo json_encode(['error' => 'Invalid request method.']);
}
?>
