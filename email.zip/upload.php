<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
</head>
<body>
    <h1>Admin Panel</h1>

    <h2>Upload SMTP Settings</h2>
    <form action="upload_smtp.php" method="post" enctype="multipart/form-data">
        <label for="smtpFile">Choose SMTP settings file:</label>
        <input type="file" name="smtpFile" id="smtpFile">
        <button type="submit">Upload</button>
    </form>

    <h2>Upload Contacts</h2>
    <form action="upload_contacts.php" method="post" enctype="multipart/form-data">
        <label for="contactsFile">Choose contacts file:</label>
        <input type="file" name="contactsFile" id="contactsFile">
        <button type="submit">Upload</button>
    </form>

    <h2>Add Content</h2>
    <form action="add_content.php" method="post">
        <label for="subject">Subject:</label>
        <input type="text" name="subject" id="subject" required>
        <label for="body">Body:</label>
        <textarea name="body" id="body" required></textarea>
        <button type="submit">Add Content</button>
    </form>

    <h2>List of Uploaded Data</h2>
    <a href="list_data.php">View Uploaded Data</a>
</body>
</html>
