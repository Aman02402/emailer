<?php
 include 'db.php';

 
// Initialize message
$message = '';
 
if (isset($_GET['token'])) {
    
    $token=$_GET['token'];
    // Prepare the SQL query to find the record with the given token
    $sql = "SELECT * FROM email_logs WHERE token = '$token'";
    $result = $conn->query($sql);
 
 

    // Check if a record was found
    if ($result->num_rows > 0) {
         // Fetch the data into an associative array
        $data = $result->fetch_assoc();
        $email = $data['recipient_email'];
        $compaign_id = $data['compaign_id'];
        $from_email = $data['from_email'];
        $smtp_id = $data['smtp_id'];
        $contact_id = $data['contact_id'];



        // Check if the email exists in the contact table
        $sql_contact = "SELECT * FROM contacts WHERE email = '$email'";
        $result_contact = $conn->query($sql_contact);


        if ($result_contact->num_rows > 0) {
             // Fetch the contact data
            $contact_data = $result_contact->fetch_assoc();
            $name = $contact_data['name'];
  
            // Delete the record from the contact table
            $sql_delete = "DELETE FROM contacts WHERE email = '$email'";
            $conn->query($sql_delete);

            // Insert the record into the unsubscribe_contact table
            $sql_insert = "INSERT INTO unsubscribe_contacts (name, email,from_email,smtp_id,campaign_id,contact_id) VALUES ('$name', '$email','$from_email','$smtp_id','$compaign_id','$contact_id')";
            $conn->query($sql_insert);

            $message = "Your email has been successfully unsubscribed ";
        } else {
            $message = "Email not found in the contact table.";
        }
    } else {
        $message = "No record found for the provided token.";
    }
} else {
    $message = "Invalid token.";
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe Status</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Unsubscribe Successfully</h1>
        <div class="alert alert-info text-center">
            <?php echo htmlspecialchars($message); ?>
        </div>
        <div class="text-center">
            <!--<p>If you have any questions or need further assistance, please <a href="mailto:support@example.com">contact us</a>.</p>-->
            <!--<p><a href="https://www.example.com" class="btn btn-primary">Return to Homepage</a></p>-->
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
