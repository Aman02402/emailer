<?php
include 'db.php';

// Initialize message
$message = '';
if (isset($_GET['email']) && isset($_GET['campaign_id'])) {
    $email = $_GET['email'];
    $campaign_id = $_GET['campaign_id'];
    $reason = $_GET['unsubscribereason'];
    $from_email = 'zoho@example.com'; // Static from_email value for Zoho

    // Prepare SQL query to fetch the record from `contacts` table
    $stmt = $conn->prepare("SELECT * FROM contacts WHERE email = ? AND FIND_IN_SET(?, campaign_id) > 0");
    $stmt->bind_param("ss", $email, $campaign_id);

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a match is found
    if ($row = $result->fetch_assoc()) {
        // Extract the contact_id from the contacts table
        $contact_id = $row['id'];

        // Remove the campaign_id from the existing comma-separated list in `campaign_id` column
        $existing_campaign_ids = explode(',', $row['campaign_id']);
        $new_campaign_ids = array_diff($existing_campaign_ids, [$campaign_id]);
        $new_campaign_ids_str = implode(',', $new_campaign_ids);

        // Update the `campaign_id` column with the updated list
        $stmt_update_campaign = $conn->prepare("UPDATE contacts SET campaign_id = ? WHERE id = ?");
        $stmt_update_campaign->bind_param("si", $new_campaign_ids_str, $contact_id);
        $stmt_update_campaign->execute();
        $stmt_update_campaign->close();

        // Check if `unsubscribe_campaign_id` column is empty or has values
        $unsubscribe_campaign_ids = $row['unsubscribe_campaing_id'];
        
        // Create an array of existing `unsubscribe_campaign_ids` if not empty
        if ($unsubscribe_campaign_ids) {
            $unsubscribe_campaign_ids_array = explode(',', $unsubscribe_campaign_ids);
        } else {
            $unsubscribe_campaign_ids_array = [];
        }

        
      if(empty($unsubscribe_campaign_ids)){
          $updated_unsubscribe_campaign_ids=$campaign_id;
       }else{
          echo 'aefds';
          $updated_unsubscribe_campaign_ids=$unsubscribe_campaign_ids.','.$campaign_id;
      }
      

        // Convert the array back into a comma-separated string
 
        // Update the `unsubscribe_campaign_id` column
        $stmt_update_unsubscribe = $conn->prepare("UPDATE contacts SET unsubscribe_campaing_id = ? WHERE id = ?");
        $stmt_update_unsubscribe->bind_param("si", $updated_unsubscribe_campaign_ids, $contact_id);
        if ($stmt_update_unsubscribe->execute()) {
            $message = 'You have been unsubscribed successfully.';
        } else {
            $message = 'Failed to update unsubscribe campaign.';
        }

        // Debugging: Show the updated unsubscribe_campaign_id value
        // echo "Updated Unsubscribe Campaign IDs: " . $updated_unsubscribe_campaign_ids;

        $stmt_update_unsubscribe->close();

         // Insert into `unsubscribe_contacts` table
        $stmt_insert = $conn->prepare("INSERT INTO unsubscribe_contacts (name, email, reason, campaign_id, from_email, contact_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt_insert->bind_param("sssssi", $row['name'], $row['email'], $reason, $campaign_id, $from_email, $contact_id);
        
        if ($stmt_insert->execute()) {
            $message = 'You have been unsubscribed successfully.';
        } else {
            $message = 'Failed to unsubscribe. Please try again.';
        }


        // Close the insert statement
        $stmt_insert->close();
    } else {
        $message = "No matching record found.";
    }

    // Close the select statement
    $stmt->close();
} else {
    $message = "Missing email or campaign_id.";
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe Status</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Unsubscribe Status</h1>
        <div class="alert alert-info text-center">
            <?php echo htmlspecialchars($message); ?>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
