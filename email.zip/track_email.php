<?php
// Database connection
$servername = "localhost";
$username = "u291199864_email";
$password = "Email123@123";
$dbname = "u291199864_email";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $emailId = $_GET['id'];
    
    // Sanitize input to prevent SQL injection
 
     // Prepare the SQL query
    $sql = "UPDATE email_logs SET viewed = '1' WHERE token = '$emailId'";
    
    // Execute the query
    if ($conn->query($sql) === TRUE) {
     } else {
        // echo "Error updating record: " . $conn->error;
    }
}




// Close the connection
$conn->close();







?>





